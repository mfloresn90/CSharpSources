﻿Judah's Finite Automata Spam Filter

1. To Run
	On Windows, start the SpamFilterAutomata.exe with a messagefile.txt in the same directory.

2. To Compile
	Open the SpamFilterAutomata.sln in visual studio and click build.  Once built, a debugging session can be started by pressing the start arrow or going into the project folders and going to /bin/Debug/SpamfilterAutomata.exe.

The Automata will go through the documents and report which messages are spam.